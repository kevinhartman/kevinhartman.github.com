package mn.hart.example;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

public class StrategyDemoService extends Service {
	
	ReentrantReadWriteLock readWriteLock;
	
	/**
	 * The strategy that our service is currently using
	 */
	private AbstractStrategy curStrategy = null;
	
	/**
	 * Return the binder for our AIDL-made service.
	 */
	@Override
	public IBinder onBind(Intent intent) {
		readWriteLock = new ReentrantReadWriteLock();
		return mBinder;
	}
	
	/**
	 * The implementation of our IBinder.
	 */
	private final IStrategyService.Stub mBinder = new IStrategyService.Stub() {

		/**
		 * Set the Strategy of our service.
		 * @param strategy The new strategy
		 */
		public void setStrategy(AbstractStrategy strategy) throws RemoteException {
			Lock writeLock = readWriteLock.writeLock();
		    writeLock.lock();
		    try {
		    	curStrategy = strategy;
		    } finally {
		        writeLock.unlock();
		    }
		}

		/**
		 * Get the service's current curStrategy
		 * @return The current curStrategy
		 */
		public AbstractStrategy getStrategy() throws RemoteException {
			Lock readLock = readWriteLock.readLock();
		    readLock.lock();
		    AbstractStrategy strategy = null;
		    try {
		    	strategy = curStrategy;
		    } finally {
		        readLock.unlock();
		    }
			
			return strategy;
		}
	};
}
