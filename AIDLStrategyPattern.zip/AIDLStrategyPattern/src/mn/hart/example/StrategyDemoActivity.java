package mn.hart.example;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

public class StrategyDemoActivity extends Activity {
    
	IStrategyService mIStrategyService;
	
	/**
	 * The service connection to our StrategyService
	 */
	private ServiceConnection mConnection = new ServiceConnection() {
		
		/**
		 * When the service is bound, run our example code.
		 */
	    public void onServiceConnected(ComponentName className, IBinder service) {
	    	mIStrategyService = IStrategyService.Stub.asInterface(service);
	        
	    	// Shows that our strategies are in tact after being shuttled to the
	    	// service and back.
	        try {
				Log.i("Setting strategy to IntervalStrategy", "...");
				mIStrategyService.setStrategy(new IntervalStrategy(100L));
				Log.i("IntervalStrategy:", "");
				Log.i("", "pingInterval => " + ((IntervalStrategy)mIStrategyService.getStrategy()).getPingInterval());

				Log.i("Setting strategy to RandomStrategy", "...");
				mIStrategyService.setStrategy(new RandomStrategy("randomness"));
				Log.i("RandomStrategy:", "");
				Log.i("", "seed => " + ((RandomStrategy)mIStrategyService.getStrategy()).getSeed());		
	        } catch (RemoteException e) {
				Log.e("FAIL", "");
			}  
	    }

	    /**
	     * When our services is unexpectedly killed
	     */
	    public void onServiceDisconnected(ComponentName className) {
	        Log.e("StrategyDemoActivity", "Service has unexpectedly disconnected");
	        mIStrategyService = null;
	    }
	};
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("StrategyDemoActivity", "onCreate");
        bindService(new Intent("mn.hart.example.StrategyDemoService"), mConnection, Context.BIND_AUTO_CREATE);
        Log.i("StrategyDemoActivity", "binding...!");
        
         
    }
}