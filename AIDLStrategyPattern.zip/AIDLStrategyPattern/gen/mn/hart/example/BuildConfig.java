/** Automatically generated file. DO NOT MODIFY */
package mn.hart.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}