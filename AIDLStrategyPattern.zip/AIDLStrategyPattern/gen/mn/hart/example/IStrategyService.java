/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/kevin/Documents/Development/Android/Eclipse Workspaces/current-android-client/AIDLStrategyPattern/src/mn/hart/example/IStrategyService.aidl
 */
package mn.hart.example;
public interface IStrategyService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements mn.hart.example.IStrategyService
{
private static final java.lang.String DESCRIPTOR = "mn.hart.example.IStrategyService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an mn.hart.example.IStrategyService interface,
 * generating a proxy if needed.
 */
public static mn.hart.example.IStrategyService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof mn.hart.example.IStrategyService))) {
return ((mn.hart.example.IStrategyService)iin);
}
return new mn.hart.example.IStrategyService.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_setStrategy:
{
data.enforceInterface(DESCRIPTOR);
mn.hart.example.AbstractStrategy _arg0;
if ((0!=data.readInt())) {
_arg0 = mn.hart.example.AbstractStrategy.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.setStrategy(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_getStrategy:
{
data.enforceInterface(DESCRIPTOR);
mn.hart.example.AbstractStrategy _result = this.getStrategy();
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements mn.hart.example.IStrategyService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
public void setStrategy(mn.hart.example.AbstractStrategy strategy) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((strategy!=null)) {
_data.writeInt(1);
strategy.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_setStrategy, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
public mn.hart.example.AbstractStrategy getStrategy() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
mn.hart.example.AbstractStrategy _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getStrategy, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = mn.hart.example.AbstractStrategy.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_setStrategy = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getStrategy = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
}
public void setStrategy(mn.hart.example.AbstractStrategy strategy) throws android.os.RemoteException;
public mn.hart.example.AbstractStrategy getStrategy() throws android.os.RemoteException;
}
